-- Create Customer table (Question 3.1)
CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    CustomerFullName VARCHAR(255) NOT NULL,
    CustomerEmail VARCHAR(255)
);

-- Create Orders table (Question 3.2)
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    OrderNumber VARCHAR(255) NOT NULL,
    CustomerID INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

-- Insert data (Question 3.3)
INSERT INTO Customer (CustomerID, CustomerFullName, CustomerEmail)
VALUES (1, 'Debbie Duncan', 'dduncan@yahoo.com');

INSERT INTO Orders (OrderID, OrderNumber, CustomerID, OrderDate)
VALUES (1, '020149', 1, '2025-02-14');